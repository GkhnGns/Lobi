<?php
// YEREL ZAAMN
date_default_timezone_set('Europe/Istanbul');
// KARAKTER DÜZENLE
$tr = array("Ç","ç","Ğ","ğ","İ","ı","Ö","ö","Ş","ş","Ü","ü","-","_","&","'"," ","/","!","?");
$en = array("C","c","G","g","I","i","O","o","S","s","U","u","-","_","ve","","-","-","",""); 
?>