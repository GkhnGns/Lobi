﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'nl', {
    WordCount: 'Woorden:',
    CharCount: 'Tekens:',
    CharCountWithHTML: 'Tekens (inclusief HTML):',
    Paragraphs: 'Paragraven:',
    pasteWarning: 'De tekst kan niet worden geplakt omdat de limiet is overschreden',
    Selected: 'Selected: ',
    title: 'Statistieken'
});
